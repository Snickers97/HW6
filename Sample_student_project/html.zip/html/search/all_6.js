var searchData=
[
  ['main_5fsavitch_5f14',['main_savitch_14',['../namespacemain__savitch__14.html',1,'']]],
  ['make_5fmove',['make_move',['../classmain__savitch__14_1_1game.html#a20597d0caa907aea47b27fed8be3759b',1,'main_savitch_14::game']]]
];
