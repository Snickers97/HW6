var searchData=
[
  ['clone',['clone',['../classmain__savitch__14_1_1game.html#a7b663057f59210dd52738facfc40d959',1,'main_savitch_14::game::clone()'],['../classmain__savitch__14_1_1Othello.html#ab5a505f8a6ffd860376bf074c57e8a5f',1,'main_savitch_14::Othello::clone()']]],
  ['compute_5fmoves',['compute_moves',['../classmain__savitch__14_1_1game.html#a2c0c049f5861026d0f639b5837889b7a',1,'main_savitch_14::game::compute_moves()'],['../classmain__savitch__14_1_1Othello.html#aae15562565348c574b8e4c0b7782d19f',1,'main_savitch_14::Othello::compute_moves()']]]
];
