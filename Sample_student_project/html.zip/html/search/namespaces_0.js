var searchData=
[
  ['main_5fsavitch_5f14',['main_savitch_14',['../namespacemain__savitch__14.html',1,'']]]
];
