var searchData=
[
  ['evaluate',['evaluate',['../classmain__savitch__14_1_1game.html#a9b9c8c5e9aa57c9a430f20b87cb047aa',1,'main_savitch_14::game::evaluate()'],['../classmain__savitch__14_1_1Othello.html#a1b3239a14882cbc7e7bd44c0b6828514',1,'main_savitch_14::Othello::evaluate()']]]
];
