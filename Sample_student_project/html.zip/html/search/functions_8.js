var searchData=
[
  ['restart',['restart',['../classmain__savitch__14_1_1game.html#ad521a7d78e7c163a0bc28b709f0d45fd',1,'main_savitch_14::game::restart()'],['../classmain__savitch__14_1_1Othello.html#abf872b8074bfa4c04119317dc3b39af2',1,'main_savitch_14::Othello::restart()']]]
];
