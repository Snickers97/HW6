var searchData=
[
  ['who',['who',['../classmain__savitch__14_1_1game.html#a4fe20fb287f809ae2b68e28e4ccba634',1,'main_savitch_14::game']]]
];
