var searchData=
[
  ['is_5fgame_5fover',['is_game_over',['../classmain__savitch__14_1_1game.html#a49eed20648918b03fd3e2cf78987b3d1',1,'main_savitch_14::game::is_game_over()'],['../classmain__savitch__14_1_1Othello.html#a4387d20f953aab54025760ec3f72f7ca',1,'main_savitch_14::Othello::is_game_over()']]],
  ['is_5flegal',['is_legal',['../classmain__savitch__14_1_1game.html#ad38351422ca1ee3ae58440c1c6b36b30',1,'main_savitch_14::game']]]
];
